# Viral Hook Writer: a free Claude skill by Kliqo Network

Writes 10 hooks for your next short video, scores them, and gives you the best 3 (spoken line, on-screen text,
first visual).

## Install
- **Claude.ai / Claude desktop app:** Settings -> Capabilities -> Skills -> Upload skill -> choose `viral-hook-writer.zip`.
  (Skills need Code execution / file creation turned on in Settings.)
- **Claude Code:** unzip into `~/.claude/skills/` so you get `~/.claude/skills/viral-hook-writer/SKILL.md`.

## Use
Ask Claude: "Write hooks for my video about ..." or paste your script and say "give me a viral hook".

Follow @kliqonetwork for more free tools.
