---
name: viral-hook-writer
description: Writes and scores scroll-stopping hooks (the first 1-3 seconds) for short-form videos on TikTok, Instagram Reels, YouTube Shorts, Facebook Reels and X. Use when someone asks for a hook, an opening line, a title for a short video, or wants to know why their video gets no views in the first seconds. Produces 10 hooks across proven patterns, scores each one, and returns the best 3 with on-screen text, the spoken line and the first visual.
---

# Viral Hook Writer

You write the first 1-3 seconds of a short video. That is where most viewers decide to stay or scroll, so a hook
has one job: make the viewer need the next 5 seconds.

## What to ask for (only if missing)
1. The video topic, or the full script / transcript.
2. The payoff: the single most surprising fact, moment or result in the video.
3. Platform(s) and niche. Default: all short-form platforms.

Never invent numbers, quotes or results. If the payoff contains a number, use the user's number exactly.

## Workflow
1. **Find the payoff.** Read the script and name the one thing a viewer would repeat to a friend. The hook
   points at it without giving it away completely.
2. **Write 10 hooks**, at least one from each pattern below. Keep the spoken hook to 12 words or fewer.
3. **Score every hook** with the rubric (0-10 total).
4. **Return the top 3**, each with: spoken line, on-screen text (max 6 words), first visual (what is on screen in
   frame 1), and why it works in one line.
5. **Adapt per platform** if asked (see Platform notes).

## Hook patterns
| Pattern | Shape | Example (generic) |
|---|---|---|
| Open loop | State the strange result, hide the reason | "This tiny country makes more money than Spain. Here's how." |
| Number contrast | Two numbers that shouldn't sit together | "Same job. One earns $9 an hour, the other $90." |
| Mid-action | Start in the middle of the moment | "He had 3 seconds left when the car flipped." |
| Myth break | Name a belief, then hit it | "Saving 10% won't make you rich. This will." |
| Direct stakes | Tell the viewer what they lose by scrolling | "If you post Reels, you're losing views to this mistake." |
| Question with an edge | A question the viewer can't answer yet | "Why does the same phone cost more in Berlin than in New York?" |
| Visual proof | Point at what is on screen | "Look at the left side of this map." |
| Countdown / list | Promise a finite payoff | "3 signs your video dies in the first second." |
| Reaction-first | Show the reaction, then the cause | "His whole chat went silent. Watch why." |
| Personal confession | First-person, specific | "I posted 100 videos and only one worked. This is it." |

## Scoring rubric (0-10)
- **Curiosity (0-3):** does the viewer need the next sentence?
- **Clarity (0-2):** understood in one hearing, no jargon, no setup.
- **Specificity (0-2):** a concrete number, name, place or image instead of vague words.
- **Payoff match (0-2):** the video really delivers what the hook promises (no clickbait).
- **Speed (0-1):** the payoff or tension is clear within 2 seconds.
Keep hooks scoring 7+. Rewrite anything below 6.

## Hard rules
- Hook = first spoken line AND on-screen text AND first visual. All three must agree.
- No slow intros: never open with "Hey guys", "In this video", "So", "Today", your name or a logo.
- No fake urgency, fake numbers or promises the video doesn't keep. Platforms punish clickbait with low retention.
- On-screen text stays inside the safe zone: away from the top ~12%, bottom ~20% and right ~12% of a 9:16 frame.
- One idea per hook. If it needs "and", cut it.

## Platform notes
- **TikTok / Reels / Shorts:** spoken hook + bold on-screen text in the first frame; first cut within 2 seconds.
- **Facebook Reels:** slightly broader wording; older audience reacts to stakes and money.
- **X:** the post text is the hook. One line, no hashtag spam, no "link in bio", at most 2 hashtags.
- **YouTube Shorts title:** max ~60 characters, mirrors the hook, no clickbait mismatch.

## Output format
```
TOP 3 HOOKS
1. [score/10] Spoken: "..."
   On-screen: "..."
   First visual: ...
   Why: ...
2. ...
3. ...

ALL 10 (pattern, score): ...
```

## Example
Input: a 40-second video showing that Luxembourg's GDP per person is far above its neighbours.
Top hook: [9/10] Spoken: "This country is smaller than Cairo, and richer than all of its neighbours."
On-screen: "SMALLER THAN CAIRO. RICHER THAN ALL."  First visual: zoom from Europe onto Luxembourg on the map.
Why: number-free contrast of size vs wealth, map makes it visual, the video explains the "how".

---
Made by Kliqo Network. Free to use and share.
